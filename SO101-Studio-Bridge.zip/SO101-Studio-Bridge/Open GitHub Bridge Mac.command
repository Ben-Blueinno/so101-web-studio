#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
python=python3
if command -v python3.12 >/dev/null; then python=python3.12; fi
if [ -x .robot-venv/bin/python ]; then python=.robot-venv/bin/python; fi
"$python" -B web_studio.py --hosted --no-browser
result=$?
if [ "$result" -ne 0 ]; then read -r -p "Press Return to close."; fi
exit "$result"
