@echo off
setlocal
cd /d "%~dp0" || exit /b 1
if exist ".robot-venv\Scripts\python.exe" (
    ".robot-venv\Scripts\python.exe" -B web_studio.py --hosted --no-browser
) else (
    py -3.12 -B web_studio.py --hosted --no-browser
)
set "result=%errorlevel%"
if not "%result%"=="0" pause
exit /b %result%
