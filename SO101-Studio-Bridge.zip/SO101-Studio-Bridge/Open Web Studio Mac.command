#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if command -v python3.12 >/dev/null; then
    python3.12 -B web_studio.py
else
    python3 -B web_studio.py
fi
result=$?
if [ "$result" -ne 0 ]; then
    read -r -p "Press Return to close."
fi
exit "$result"
