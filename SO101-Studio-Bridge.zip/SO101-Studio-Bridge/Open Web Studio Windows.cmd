@echo off
setlocal
cd /d "%~dp0" || exit /b 1
py -3.12 -c "pass" >nul 2>&1
if errorlevel 1 (
    python -B web_studio.py
) else (
    py -3.12 -B web_studio.py
)
set "result=%errorlevel%"
if not "%result%"=="0" pause
exit /b %result%
