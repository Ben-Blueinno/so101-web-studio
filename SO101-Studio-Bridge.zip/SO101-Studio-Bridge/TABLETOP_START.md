# SO-101 Web Studio

Extract the whole starter folder. Double-click **Open Web Studio Mac.command** or **Open Web Studio Windows.cmd**. A local Python process starts the browser workspace at `http://127.0.0.1:8765`. Keep the launcher window open while using the Studio.

## Connect and calibrate

1. In **Settings**, choose follower A or B. Scan for serial ports or type the port, enter the LeRobot ID, and save the profile. With an existing installation, copy your previous `tabletop.ini` and any referenced local calibration files into the new folder. An empty calibration path uses LeRobot’s default for the selected ID.
2. In **Arm setup**, use **Initialize arm** to verify the stored motor calibration and read the current joint positions. This starts the live 3D view and reads the starting pose without enabling torque. Use **Read current pose** to refresh the model and set a new starting pose, then preview again.
3. If you need an existing calibration, use **Read motor calibration** to review values stored on the motors, or import a known JSON in **Settings**. Save the copy, select **Use for profile**, and save the profile. **Apply saved calibration** writes that arm’s known calibration back to the motors.
4. For a new calibration, disconnect, save the profile with its default calibration path, and choose **Calibrate new**. Support the arm as torque is released. Capture the midpoint and sweep each joint by hand as instructed. Select **Save range**. [LeRobot SO-101 calibration guide](https://huggingface.co/docs/lerobot/so101#calibrate)

### Return to rest

The first pose read at initialization is the session rest pose unless you have saved one for this follower and calibration. In **Arm setup**, select **Save current pose as rest** to keep a different pose across restarts. **Read current pose** refreshes the preview without changing the rest pose.

Select **Return to rest** and review the warning and the order of joints. After you confirm a clear path, Studio moves the joints one at a time, checks the encoder readings, and stops if a joint fails to reach its target. Use **Stop return to rest** to interrupt movement.

## Program, preview, and deploy

1. In **Python & 3D**, edit the starter program or open **Python Codebook**. The starter uses LeRobot’s `robot.get_observation()` and `robot.send_action()` with one joint per action. Numeric variables, arithmetic, bounded loops, and earlier `move()` and `grip()` programs also work. Use **Save in browser** or **Download .py** to keep programs. **Import .py or route JSON** also opens routes from previous versions.
2. Select **Preview in 3D** and watch the route complete. Verify each joint’s direction in **Settings**, then initialize or read the arm before previewing for deployment. The model estimates the joint angles from the measured positions and calibration. The animation previews joint travel and highlights the active motor in amber. Check the real arm’s surroundings for collisions.
3. Select **Prepare deployment**. The Studio validates the targets using the real follower’s calibration. Review the current target, clear its physical sweep, then select **Confirm and move this step**. Repeat for every step. During motion, the active motor is highlighted in blue. After each move the model updates to the encoder readings. Read the before, target, and measured values beneath each result.
4. To pause an active step, select **Stop sending movement**. This stops new target updates and can leave the arm holding position. Use the physical power cutoff if you need an emergency stop. Support the arm before using **Disconnect arm**.

The browser workspace runs on the computer connected to the USB arm. Hardware functions need the Python environment containing LeRobot with Feetech support. If needed, set `python` under `[setup]` in `tabletop.ini` to its Python executable. Simulation works without a connected robot.

## Export into an existing LeRobot project

Expand **Export to a LeRobot project** and select **Generate LeRobot function**. Copy the generated module or download it as a Python file. In your project, import `run_route` and pass your connected, calibrated `SO101Follower` configured with `use_degrees=True`.

```python
from my_route_lerobot import run_route

run_route(robot)
```

The function reads the starting pose from the follower, checks every target against its calibration, then sends the action targets using LeRobot. An optional `approve(step_number, action)` callback lets the calling project confirm each step. Native LeRobot editor values already use motor coordinates. Exports from earlier `move()` / `grip()` programs use the selected profile’s verified direction signs. Supply any missing signs through `joint_directions={"shoulder_pan": 1}` using values verified for your arm. The project owns connection and calibration.
