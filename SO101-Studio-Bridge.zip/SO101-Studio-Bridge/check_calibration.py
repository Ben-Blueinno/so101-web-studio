"""Compare the saved SO-101 calibration with the motors over the serial bus."""
import argparse
from importlib.metadata import version
import sys


def check(robot):
    print(f"Calibration file: {robot.calibration_fpath}", flush=True)
    if not robot.calibration:
        print("No calibration loaded for this ID. Check the ID and LeRobot environment.")
        return 2

    bus = robot.bus
    try:
        bus.connect()
        measured = bus.read_calibration()
    finally:
        if bus.is_connected:
            bus.disconnect(disable_torque=False)

    fields = ["range_min", "range_max"]
    if bus.protocol_version != 1:
        fields.append("homing_offset")

    differences = []
    for name in sorted(robot.calibration.keys() | measured.keys()):
        saved = robot.calibration.get(name)
        motor = measured.get(name)
        if saved is None:
            differences.append(f"{name}: missing from saved calibration")
        elif motor is None:
            differences.append(f"{name}: missing from motor readings")
        else:
            for field in fields:
                saved_value = getattr(saved, field)
                motor_value = getattr(motor, field)
                if saved_value != motor_value:
                    differences.append(f"{name} {field}: saved {saved_value}, motor {motor_value}")

    if differences:
        print("Calibration mismatch")
        for difference in differences:
            print(f"  {difference}")
        return 2

    print("Calibration matches the connected motors.")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True)
    parser.add_argument("--id", required=True)
    args = parser.parse_args()
    print(f"SO-101 calibration check for {args.id} on {args.port}", flush=True)
    try:
        from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig

        print(f"LeRobot {version('lerobot')} using {sys.executable}", flush=True)
        robot = SO101Follower(SO101FollowerConfig(
            port=args.port, id=args.id, use_degrees=True, disable_torque_on_disconnect=False,
        ))
        return check(robot)
    except Exception as error:
        print(f"Check failed ({type(error).__name__}): {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
