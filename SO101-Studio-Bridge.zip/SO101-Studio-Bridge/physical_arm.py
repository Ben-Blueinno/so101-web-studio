"""Small, supervised base-joint exercises for LeRobot 0.6.0 SO-101 followers.
No leader mode and no manual back-driving. Run beside the actual robot.
"""
import math
import time

KEYS = tuple(name + '.pos' for name in (
    'shoulder_pan', 'shoulder_lift', 'elbow_flex', 'wrist_flex', 'wrist_roll', 'gripper'))


def validate_poses(data, robot_id):
    if data.get('schema') != 'so101-base-poses-v1' or data.get('robot_id') != robot_id:
        raise ValueError('Wrong format or arm ID. Do not reuse another arm’s recording.')
    if data.get('units') != 'body_degrees_gripper_percent':
        raise ValueError('Unexpected units.')
    poses = data.get('poses')
    if not isinstance(poses, list) or not 2 <= len(poses) <= 20:
        raise ValueError('Save between 2 and 20 poses.')
    for pose in poses:
        if set(pose) != set(KEYS):
            raise ValueError('Every pose must contain six joint positions.')
        if not all(type(x) in (int, float) and math.isfinite(x) for x in pose.values()):
            raise ValueError('Positions must be finite numbers.')
    return poses


def make_follower(port, robot_id, calibration_file=None, disable_torque_on_disconnect=True):
    from lerobot.robots.so_follower.so_follower import SO101Follower
    from lerobot.robots.so_follower.config_so_follower import SO101FollowerConfig

    robot = SO101Follower(SO101FollowerConfig(
        port=port, id=robot_id, use_degrees=True, max_relative_target=1.0,
        disable_torque_on_disconnect=disable_torque_on_disconnect))
    if calibration_file is not None:
        robot._load_calibration(calibration_file)
        robot.calibration_fpath = calibration_file
        robot.bus.calibration = robot.calibration
    return robot


def validate_calibration(robot):
    motors = robot.bus.motors
    if not robot.calibration or set(robot.calibration) != set(motors):
        raise ValueError("Calibration must contain all six motors. Check the file/ID or run calibrate.")
    for name, motor in motors.items():
        cal = robot.calibration[name]
        bus = robot.bus
        resolution = (bus.resolution(motor.model) if hasattr(bus, "resolution")
                      else bus.model_resolution_table[motor.model])
        if (cal.id != motor.id or cal.drive_mode not in (0, 1)
                or not 0 <= cal.range_min < cal.range_max < resolution
                or not -(resolution - 1) <= cal.homing_offset <= resolution - 1):
            raise ValueError(f"{name}: invalid motor ID, limits, or homing offset in the calibration.")


class Arm:
    def __init__(self, port, robot_id, calibration_file=None, *, enable=True,
                 shoulder_lift_p_gain=None, shoulder_pan_p_gain=None):
        self.shoulder_gains = {}
        for motor, gain in (("shoulder_lift", shoulder_lift_p_gain), ("shoulder_pan", shoulder_pan_p_gain)):
            if gain is not None:
                if not 1 <= gain <= 255:
                    raise ValueError(f"{motor}: position gain must be between 1 and 255.")
                self.shoulder_gains[motor] = gain
        self.robot = make_follower(port, robot_id, calibration_file)
        self.robot_id = robot_id
        validate_calibration(self.robot)
        self.enabled = False
        try:
            self.robot.bus.connect()
            if not self.robot.is_calibrated:
                raise ValueError('Calibration mismatch. Run check for details.')
            if enable:
                self.enable()
            self.initial = self.read()
        except BaseException:
            self.close()
            raise

    def enable(self):
        if not self.enabled:
            self.enabled = True
            if not self.shoulder_gains:
                self.robot.configure()
            else:
                self._configure_with_shoulder_gains()

    def _configure_with_shoulder_gains(self):
        from lerobot.motors.feetech import OperatingMode

        bus = self.robot.bus
        config = self.robot.config
        bus.disable_torque()
        bus.configure_motors()
        for motor in bus.motors:
            bus.write("Operating_Mode", motor, OperatingMode.POSITION.value)
            gain = self.shoulder_gains.get(motor, config.position_p_coefficient)
            bus.write("P_Coefficient", motor, gain)
            bus.write("I_Coefficient", motor, config.position_i_coefficient)
            bus.write("D_Coefficient", motor, config.position_d_coefficient)
        # Match LeRobot's gripper protections.
        bus.write("Max_Torque_Limit", "gripper", 500)
        bus.write("Protection_Current", "gripper", 250)
        bus.write("Overload_Torque", "gripper", 25)

        for motor, gain in self.shoulder_gains.items():
            if bus.read("P_Coefficient", motor, normalize=False) != gain:
                raise RuntimeError(f"{motor}: position gain did not match the saved setting.")
        positions = bus.sync_read("Present_Position", normalize=False)
        for motor, position in positions.items():
            calibration = self.robot.calibration[motor]
            if not calibration.range_min <= position <= calibration.range_max:
                raise RuntimeError(f"{motor}: encoder position is outside calibration.")
        bus.sync_write("Goal_Position", positions, normalize=False)
        if bus.sync_read("Goal_Position", normalize=False) != positions:
            raise RuntimeError("Servo goals did not match the current pose before enabling torque.")
        bus.enable_torque()

    def read(self):
        obs = self.robot.get_observation()
        return {key: float(obs[key]) for key in KEYS}

    def calibration_signature(self):
        return [[name, motor.homing_offset, motor.range_min, motor.range_max, motor.drive_mode]
                for name, motor in sorted(self.robot.calibration.items())]

    def move_base(self, target, seconds=3, on_sample=None):
        self._move_joint(KEYS[0], target, seconds, on_sample, 20)

    def move_joint(self, key, target, seconds=3, on_sample=None, on_pose=None):
        self._move_joint(key, target, seconds, on_sample, on_pose=on_pose)

    def _encoder_scale(self, name):
        bus = self.robot.bus
        model = bus.motors[name].model
        if hasattr(bus, "resolution"):
            return 360 / (bus.resolution(model) - 1)
        return 360 / (bus.model_resolution_table[model] - 1)

    def limits(self, key):
        if key not in KEYS:
            raise ValueError(f'Unknown joint: {key}')
        name = key.removesuffix('.pos')
        if name == 'gripper':
            return 0, 100
        calibration = self.robot.calibration[name]
        span = calibration.range_max - calibration.range_min
        limit = span / 2 * self._encoder_scale(name)
        return -limit, limit

    def gripper_degrees_per_point(self):
        calibration = self.robot.calibration['gripper']
        return (calibration.range_max - calibration.range_min) * self._encoder_scale('gripper') / 100

    def _move_joint(self, key, target, seconds, on_sample, max_offset=None, on_pose=None):
        low, high = self.limits(key)
        if not low <= target <= high:
            raise ValueError('Target is outside the calibrated range.')
        if max_offset is not None and not abs(target - self.initial[key]) <= max_offset:
            raise ValueError('Target is outside the allowed session offset.')
        if not math.isfinite(seconds) or seconds < 2:
            raise ValueError('Allow at least two seconds.')
        start = self.read()[key]
        name = key.removesuffix('.pos')
        if key == KEYS[-1]:
            calibration = self.robot.calibration[name]
            tick = 100 / (calibration.range_max - calibration.range_min)
            unit = 'points'
        else:
            tick = self._encoder_scale(name)
            unit = 'deg'
        tolerance = max(0.5, tick * 1.1)
        if not low - tick <= start <= high + tick:
            raise RuntimeError(f'{name} reading {start:.2f} {unit} is outside the calibrated range.')

        duration = max(seconds, abs(target - start) / 5)
        started = time.monotonic()
        last_progress = None
        best_error = abs(target - start)
        while True:
            observed = self.read()
            current = observed[key]
            if on_pose is not None:
                on_pose(observed)
            if not low - tick <= current <= high + tick:
                raise RuntimeError(f'{name} reading {current:.2f} {unit} is outside the calibrated range.')
            if on_sample is not None:
                on_sample(current)
            error = abs(target - current)
            if error <= tolerance:
                return
            now = time.monotonic()
            if best_error - error >= max(0.1, tick * 0.75):
                best_error = error
                if last_progress is not None:
                    last_progress = now
            if last_progress is not None and now - last_progress >= 3:
                raise RuntimeError(f'{name}: No progress for 3 seconds '
                                   f'(read {current:.2f}, target {target:.2f} {unit}).')
            if now - started >= duration * 4 + 3:
                raise RuntimeError(f'{name}: Move timed out (read {current:.2f}, target {target:.2f} {unit}).')

            progress = (now - started) / duration
            planned = target if progress >= 1 else start + (target - start) * progress
            # Pause the ramp when the motor lags. Match LeRobot's per-command limit.
            if (planned - current) * (target - current) > 0:
                demand = target if error <= 1.0 else current + math.copysign(1.0, target - current)
                goal = min(planned, demand) if target > current else max(planned, demand)
                goal = min(high, max(low, goal))
                self.robot.send_action({key: goal})
                # Give the servo time to respond after the ramp supplies the available demand.
                if last_progress is None and goal == demand:
                    last_progress = now
            time.sleep(0.05)

    def replay(self, data):
        poses = validate_poses(data, self.robot_id)
        current = self.read()
        # Validate the whole sequence BEFORE issuing any movement command.
        for pose in poses:
            if abs(pose['shoulder_pan.pos'] - self.initial['shoulder_pan.pos']) > 20:
                raise ValueError('Recording exceeds the session’s base movement envelope.')
            for key in KEYS[1:]:
                if abs(pose[key] - current[key]) > 3:
                    raise ValueError('Other joints differ from the recording. Teacher must restore the starting posture.')
        if abs(current['shoulder_pan.pos'] - poses[0]['shoulder_pan.pos']) > 3:
            raise ValueError('Start near the first saved pose; automatic return is intentionally disabled.')
        for pose in poses:
            self.move_base(pose['shoulder_pan.pos'], seconds=3)
            time.sleep(1)

    def close(self):
        if self.robot.bus.is_connected:
            if self.enabled:
                self.robot.disconnect()
            else:
                self.robot.bus.disconnect(disable_torque=False)
