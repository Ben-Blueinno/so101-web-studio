"""Local teacher settings editor. It never opens a serial connection or writes to a motor."""
import io
import json
import os
import re
import subprocess
import sys
import tempfile
from configparser import ConfigParser, Error as ConfigError
from pathlib import Path
from uuid import uuid4

from physical_arm import KEYS
from tabletop import classroom_python, profiles

JOINTS = tuple(key.removesuffix(".pos") for key in KEYS)
FIELDS = ("port", "id", "calibration_file", *JOINTS)
MAX_CAL_BYTES = 16384


def atomic_write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as out:
        temp = Path(out.name)
        try:
            out.write(text)
        except BaseException:
            out.close()
            temp.unlink()
            raise
    try:
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def calibration_json(text):
    if len(text.encode("utf-8")) > MAX_CAL_BYTES:
        raise ValueError("Calibration file is too large.")
    data = json.loads(text)
    fields = {"id", "drive_mode", "homing_offset", "range_min", "range_max"}
    if not isinstance(data, dict) or set(data) != set(JOINTS):
        raise ValueError("A LeRobot calibration must contain all six SO-101 joints.")
    for index, name in enumerate(JOINTS, 1):
        m = data[name]
        if (not isinstance(m, dict) or set(m) != fields
                or any(type(v) is not int for v in m.values()) or m["id"] != index
                or m["drive_mode"] not in (0, 1)
                or not -4095 <= m["homing_offset"] <= 4095
                or not 0 <= m["range_min"] < m["range_max"] <= 4095):
            raise ValueError(f"{name}: invalid LeRobot motor ID, drive mode, homing offset, or range.")
    return json.dumps(data, indent=2) + "\n"


class SetupStore:
    def __init__(self, root):
        self.root = root.resolve()
        self.settings = self.root / "tabletop.ini"
        self.folder = self.root / "calibrations"

    def read(self):
        config = ConfigParser(interpolation=None)
        config.read(self.settings, encoding="utf-8-sig")
        return config

    def save_profile(self, label, values):
        if label not in ("A", "B"):
            raise ValueError("Choose profile A or B.")
        config = self.read()
        if values is None:
            config.remove_section(label)
        else:
            if not config.has_section(label):
                config.add_section(label)
            for field in FIELDS:
                config[label][field] = values.get(field, "").strip()
            profiles(config, label)
            if any(config[label][joint] not in ("", "1", "-1") for joint in JOINTS):
                raise ValueError("A joint direction must be blank, 1, or -1.")
            reference = config[label]["calibration_file"]
            if reference:
                calibration_json(self.read_calibration(self.root / Path(reference).expanduser()))
        output = io.StringIO()
        config.write(output)
        atomic_write(self.settings, output.getvalue())

    def read_calibration(self, path):
        with path.open("rb") as file:
            data = file.read(MAX_CAL_BYTES + 1)
        if len(data) > MAX_CAL_BYTES:
            raise ValueError("Calibration file is too large.")
        return data.decode("utf-8-sig")

    def save_calibration(self, name, text, overwrite=False):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", name):
            raise ValueError("File name: use 1–60 letters, digits, underscores, or hyphens.")
        if name.upper() in {"CON", "PRN", "AUX", "NUL", *[f"{p}{i}" for p in ("COM", "LPT") for i in range(10)]}:
            raise ValueError("Choose a file name that Windows supports.")
        contents = calibration_json(text)
        path = self.folder / f"{name}.json"
        self.require_managed(path)
        if path.exists():
            if not overwrite:
                raise ValueError("That calibration already exists. Choose another name or replace it.")
            atomic_write(self.archive_path(path), self.read_calibration(path))
        atomic_write(path, contents)
        return path

    def require_managed(self, path):
        if path.parent != self.folder or path.suffix != ".json" or path.is_symlink() or self.folder.is_symlink():
            raise ValueError("Only local copies in the calibrations folder can be edited or archived.")

    def archive_path(self, path):
        archive = self.folder / "archive"
        if archive.is_symlink():
            raise ValueError("The archive must be a local folder.")
        return archive / f"{path.stem}-{uuid4().hex[:10]}.json"

    def archive_calibration(self, path):
        self.require_managed(path)
        config = self.read()
        for label in ("A", "B"):
            ref = config.get(label, "calibration_file", fallback="")
            if ref and (self.root / Path(ref).expanduser()).resolve() == path.resolve():
                raise ValueError(f"Profile {label} uses this file. Change that profile's calibration and save it first.")
        archived = self.archive_path(path)
        archived.parent.mkdir(parents=True, exist_ok=True)
        path.replace(archived)
        return archived


def available_ports():
    try:
        from serial.tools.list_ports import comports
        return sorted({item.device for item in comports()})
    except ImportError:
        pass
    if sys.platform == "win32":
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM") as key:
                return sorted({winreg.EnumValue(key, i)[1] for i in range(winreg.QueryInfoKey(key)[1])})
        except FileNotFoundError:
            return []
    return sorted(str(path) for path in Path("/dev").glob("cu.*") if "Bluetooth" not in path.name)


def main():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    store = SetupStore(Path(__file__).resolve().parent)
    if "--configured" not in sys.argv:
        python = classroom_python(store.read(), store.root)
        if python is not None:
            return subprocess.run([str(python), "-B", __file__, "--configured"], check=False).returncode
    root = tk.Tk()
    root.title("SO-101 Tabletop Studio")
    root.minsize(830, 570)
    tabs = ttk.Notebook(root)
    tabs.pack(fill="both", expand=True, padx=10, pady=10)
    program = ttk.Frame(tabs, padding=16)
    hardware = ttk.Frame(tabs, padding=16)
    frame = ttk.Frame(tabs, padding=16)
    for page, title in ((program, "Python editor"), (hardware, "Arm setup"), (frame, "Settings")):
        tabs.add(page, text=title)
    frame.columnconfigure(1, weight=1)
    frame.rowconfigure(1, weight=1)
    ttk.Label(frame, text="SO-101 Teacher Setup", font=("TkDefaultFont", 19, "bold")).grid(
        columnspan=2, sticky="w")
    left = ttk.LabelFrame(frame, text="Follower profiles and ports", padding=12)
    right = ttk.LabelFrame(frame, text="Calibration files", padding=12)
    left.grid(row=1, column=0, sticky="ns", padx=(0, 12), pady=12)
    right.grid(row=1, column=1, sticky="nsew", pady=12)
    right.columnconfigure(0, weight=1)
    right.rowconfigure(4, weight=1)
    notice = tk.StringVar(value="Close any running tabletop console before using the same serial port.")
    ttk.Label(frame, textvariable=notice, wraplength=790).grid(row=2, columnspan=2, sticky="w")

    label = tk.StringVar(value="A")
    vals = {key: tk.StringVar() for key in FIELDS}
    saved_cal = tk.StringVar()
    cal_name = tk.StringVar()
    profile = ttk.Combobox(left, values=("A", "B"), textvariable=label, state="readonly", width=28)
    ttk.Label(left, text="Follower").grid(row=0, sticky="w")
    profile.grid(row=1, columnspan=2, sticky="ew", pady=(0, 8))
    ttk.Label(left, text="USB port (select or type)").grid(row=2, sticky="w")
    port = ttk.Combobox(left, textvariable=vals["port"], width=29)
    port.grid(row=3, sticky="ew")
    ttk.Label(left, text="Existing or new LeRobot ID").grid(row=4, sticky="w")
    ttk.Entry(left, textvariable=vals["id"]).grid(row=5, columnspan=2, sticky="ew", pady=(0, 8))
    ttk.Label(left, text="Calibration path (blank = LeRobot default)").grid(row=6, columnspan=2, sticky="w")
    ttk.Entry(left, textvariable=vals["calibration_file"]).grid(row=7, columnspan=2, sticky="ew")
    ttk.Label(left, text="Route directions (blank, 1, or -1)").grid(row=9, columnspan=2, sticky="w", pady=(10, 0))
    for row, joint in enumerate(JOINTS, 10):
        ttk.Label(left, text=joint.replace("_", " ").title()).grid(row=row, sticky="w")
        ttk.Combobox(left, values=("", "1", "-1"), textvariable=vals[joint],
                     state="readonly", width=4).grid(row=row, column=1, sticky="e")

    def guard(action):
        def callback():
            try:
                action()
            except (OSError, ValueError, ConfigError) as error:
                messagebox.showerror("SO-101 Setup", str(error), parent=root)
        return callback

    def refresh_profile(event=None):
        config = store.read()
        for key, value in vals.items():
            value.set(config.get(label.get(), key, fallback=""))
        configured = [f"{slot}: {config.get(slot, 'port', fallback='') or 'empty'}" for slot in ("A", "B")]
        notice.set("Saved profiles · " + "   |   ".join(configured))

    def scan():
        port["values"] = available_ports()
        notice.set("Serial ports: " + (", ".join(port["values"]) or "none found. You can still type a port."))

    def save_profile():
        store.save_profile(label.get(), {key: value.get() for key, value in vals.items()})
        refresh_profile()
        notice.set(f"Follower {label.get()} saved. Restart Start Tabletop to use these settings.")

    def clear_profile():
        if messagebox.askyesno("Remove profile?", f"Remove follower {label.get()}'s saved port and settings? "
                              "Its calibration file will remain.", parent=root):
            store.save_profile(label.get(), None)
            refresh_profile()

    ttk.Button(left, text="Scan", command=guard(scan)).grid(row=3, column=1, sticky="ew")
    ttk.Button(left, text="Use LeRobot default", command=lambda: vals["calibration_file"].set("")).grid(
        row=8, columnspan=2, sticky="w")
    ttk.Button(left, text="Save profile", command=guard(save_profile)).grid(row=16, sticky="w", pady=(10, 0))
    ttk.Button(left, text="Remove profile", command=guard(clear_profile)).grid(row=16, column=1, pady=(10, 0))
    profile.bind("<<ComboboxSelected>>", lambda _: guard(refresh_profile)())

    ttk.Label(right, text="Managed copies (original LeRobot files stay separate)").grid(row=0, sticky="w")
    picker = ttk.Combobox(right, textvariable=saved_cal, state="readonly")
    picker.grid(row=1, sticky="ew")
    actions = ttk.Frame(right)
    actions.grid(row=2, sticky="w", pady=5)
    name_row = ttk.Frame(right)
    name_row.grid(row=3, sticky="ew", pady=(0, 5))
    ttk.Label(name_row, text="Copy name").pack(side="left")
    ttk.Entry(name_row, textvariable=cal_name).pack(side="left", padx=6, fill="x", expand=True)
    editor = tk.Text(right, width=48, height=13, wrap="none", undo=True)
    editor.grid(row=4, sticky="nsew")
    scroll = ttk.Scrollbar(right, orient="vertical", command=editor.yview)
    scroll.grid(row=4, column=1, sticky="ns")
    editor.configure(yscrollcommand=scroll.set)
    bottom = ttk.Frame(right)
    bottom.grid(row=5, sticky="w", pady=(6, 0))

    def refresh_files(current=""):
        picker["values"] = sorted(p.name for p in store.folder.glob("*.json") if not p.is_symlink())
        saved_cal.set(current)

    def show_text(text, name):
        editor.delete("1.0", "end")
        editor.insert("1.0", text)
        editor.edit_reset()
        cal_name.set(name)

    def view_saved():
        if saved_cal.get():
            path = store.folder / saved_cal.get()
            show_text(store.read_calibration(path), path.stem)

    def lookup_folder():
        default = Path(os.environ.get("HF_LEROBOT_CALIBRATION", Path(
            os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "lerobot" / "calibration"))
        candidates = (default / "robots" / "so101_follower", default / "robots" / "so_follower", default)
        return next((p for p in candidates if p.is_dir()), store.root)

    def import_file():
        source = filedialog.askopenfilename(parent=root, title="Open an existing SO-101 calibration",
                                            initialdir=lookup_folder(), filetypes=[("JSON files", "*.json")])
        if source:
            path = Path(source)
            text = calibration_json(store.read_calibration(path))
            refresh_files()
            show_text(text, path.stem)
            notice.set("Opened a copy in the editor. Save it under a name to add it to the local library.")

    def create_file():
        refresh_files()
        show_text("", "")
        editor.focus_set()
        notice.set("Paste a real six-joint LeRobot calibration. To measure a new one, use calibrate A in Start Tabletop.")

    def save_cal():
        name = cal_name.get().strip()
        replacing = (store.folder / f"{name}.json").exists()
        if replacing and not messagebox.askyesno("Replace calibration copy?",
                                                "Save these edits and archive the previous copy?", parent=root):
            return
        result = store.save_calibration(name, editor.get("1.0", "end-1c"), replacing)
        refresh_files(result.name)
        view_saved()
        notice.set(f"Saved {result.name}. Select Use for profile, then Save profile to associate it.")

    def use_file():
        if not saved_cal.get():
            raise ValueError("Select a saved calibration first.")
        vals["calibration_file"].set((Path("calibrations") / saved_cal.get()).as_posix())
        notice.set(f"Selected {saved_cal.get()} for {label.get()}. Select Save profile to keep it.")

    def archive_file():
        selected = saved_cal.get()
        if not selected:
            raise ValueError("Select a saved calibration first.")
        if messagebox.askyesno("Archive calibration copy?", f"Move {selected} to calibrations/archive?", parent=root):
            archived = store.archive_calibration(store.folder / selected)
            create_file()
            notice.set(f"Moved to {archived.parent.name}/{archived.name}. The original file was not changed.")

    for container, items in ((actions, (("Import file", import_file), ("New file", create_file))),
                              (bottom, (("Save calibration", save_cal), ("Use for profile", use_file),
                                        ("Archive copy", archive_file)))):
        for caption, action in items:
            ttk.Button(container, text=caption, command=guard(action)).pack(side="left", padx=(0, 6))
    picker.bind("<<ComboboxSelected>>", lambda _: guard(view_saved)())
    guard(refresh_profile)()
    guard(refresh_files)()
    guard(scan)()

    from program_editor import build_editor
    from studio_hardware import build_hardware

    def show_readback(robot_id, contents):
        refresh_files()
        show_text(contents, f"{robot_id}-readback"[:60])
        notice.set("Review the motor readback. Save calibration creates a local copy, then Use for profile assigns it.")
        tabs.select(frame)

    build_editor(program, store.root)
    build_hardware(hardware, root, store, show_readback)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
