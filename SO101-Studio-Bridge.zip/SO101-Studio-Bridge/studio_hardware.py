"""Hardware setup for the tabletop studio. Student route code never calls this module."""
import json
import threading
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime
from queue import Empty, Queue
from shutil import copy2

from physical_arm import KEYS, make_follower, validate_calibration
from tabletop import FOLDER, profiles


@contextmanager
def serial_bus(robot):
    try:
        robot.bus.connect()
        yield robot.bus
    finally:
        if robot.bus.is_connected:
            robot.bus.disconnect(disable_torque=False)


def read_motor_calibration(robot):
    with serial_bus(robot) as bus:
        current = bus.read_calibration()
    return {name: asdict(value) for name, value in current.items()}


def initialize(robot):
    """Verify saved settings and capture the current pose without enabling torque."""
    validate_calibration(robot)
    with serial_bus(robot) as bus:
        if not robot.is_calibrated:
            actual = bus.read_calibration()
            mismatches = [name for name, saved in robot.calibration.items() if
                          name not in actual or any(getattr(saved, field) != getattr(actual[name], field)
                          for field in ("homing_offset", "range_min", "range_max"))]
            raise ValueError("Calibration mismatch: " + (", ".join(mismatches) or "check the selected follower."))
        measured = robot.get_observation()
    return {key: float(measured[key]) for key in KEYS}


def restore(robot):
    validate_calibration(robot)
    with serial_bus(robot) as bus:
        previous = bus.read_calibration()
        bus.disable_torque()
        try:
            bus.write_calibration(robot.calibration)
            if not robot.is_calibrated:
                raise ValueError("Verification failed after writing the calibration.")
        except Exception:
            bus.write_calibration(previous)
            raise


def record(robot, advance, cancelled, notify):
    from lerobot.motors import MotorCalibration
    from lerobot.motors.feetech import OperatingMode

    def wait_for_midpoint():
        while not advance.wait(.1):
            if cancelled.is_set():
                raise InterruptedError("Calibration cancelled.")
        if cancelled.is_set():
            raise InterruptedError("Calibration cancelled.")
        advance.clear()

    original = robot.calibration
    with serial_bus(robot) as bus:
        previous = bus.read_calibration()
        bus.disable_torque()
        notify("midpoint", "Support the arm. Place all joints near the middle of their travel, then click Capture midpoint.")
        wait_for_midpoint()
        try:
            for joint in bus.motors:
                bus.write("Operating_Mode", joint, OperatingMode.POSITION.value)
            offsets = bus.set_half_turn_homings()
            joints = [name for name in bus.motors if name != "wrist_roll"]
            current = bus.sync_read("Present_Position", joints, normalize=False, num_retry=5)
            lows, highs = current.copy(), current.copy()
            notify("range", "Slowly sweep each joint through its usable range by hand. Skip wrist roll. Click Save range when finished.")
            while not advance.wait(.05):
                if cancelled.is_set():
                    raise InterruptedError("Calibration cancelled.")
                current = bus.sync_read("Present_Position", joints, normalize=False, num_retry=5)
                for name in joints:
                    lows[name] = min(lows[name], current[name])
                    highs[name] = max(highs[name], current[name])
                notify("sample", "\n".join(f"{name:14} {lows[name]:4} … {highs[name]:4}" for name in joints))
            if cancelled.is_set():
                raise InterruptedError("Calibration cancelled.")
            lows["wrist_roll"], highs["wrist_roll"] = 0, 4095
            robot.calibration = {
                name: MotorCalibration(id=motor.id, drive_mode=0, homing_offset=int(offsets[name]),
                                       range_min=int(lows[name]), range_max=int(highs[name]))
                for name, motor in bus.motors.items()
            }
            validate_calibration(robot)
            path = robot.calibration_fpath
            if path.is_file():
                copy2(path, path.with_suffix(f".{datetime.now():%Y%m%d-%H%M%S-%f}.bak"))
            bus.write_calibration(robot.calibration)
            if not robot.is_calibrated:
                raise ValueError("The motors did not verify the new calibration.")
            from setup_profiles import atomic_write
            atomic_write(path, json.dumps({name: asdict(val) for name, val in robot.calibration.items()}, indent=2) + "\n")
            return f"Calibration saved and verified.\n{path}"
        except Exception as error:
            robot.calibration = original
            try:
                bus.write_calibration(previous)
            except Exception as recovery:
                raise RuntimeError(f"{error} Previous calibration could not be restored: {recovery}") from error
            raise


def build_hardware(parent, root, store, readback):
    import tkinter as tk
    from tkinter import messagebox, ttk

    label = tk.StringVar(value="A")
    status = tk.StringVar(value="Save a follower profile in Settings first. Initialization reads and verifies the starting pose.")
    sample = tk.StringVar()
    events = Queue()
    advance, cancelled = threading.Event(), threading.Event()
    phase = None
    active = False

    ttk.Label(parent, text="Follower setup").pack(anchor="w")
    ttk.Combobox(parent, values=("A", "B"), textvariable=label, state="readonly", width=8).pack(anchor="w", pady=6)
    controls = ttk.Frame(parent)
    controls.pack(anchor="w")
    ttk.Label(parent, textvariable=status, wraplength=710, justify="left").pack(anchor="w", pady=14)
    ttk.Label(parent, textvariable=sample, font="TkFixedFont", justify="left").pack(anchor="w")
    progress = ttk.Frame(parent)
    progress.pack(anchor="w", pady=8)

    def go():
        advance.set()
        next_button.state(["disabled"])

    def cancel():
        cancelled.set()
        next_button.state(["disabled"])
        cancel_button.state(["disabled"])
        status.set("Cancelling. Keep supporting the arm until the operation finishes.")

    next_button = ttk.Button(progress, text="Capture midpoint", command=go)
    cancel_button = ttk.Button(progress, text="Cancel calibration", command=cancel)

    def start(operation):
        nonlocal active
        if active:
            return
        config = store.read()
        choice = label.get()
        try:
            port, robot_id = profiles(config, choice)[choice]
        except ValueError as error:
            status.set(str(error))
            return
        path = config.get(choice, "calibration_file", fallback="").strip()
        if operation == "record" and path:
            status.set("Choose Use LeRobot default in Settings and save the profile before recording a new calibration.")
            return
        if operation in ("record", "restore") and not messagebox.askyesno(
                "Support the arm", f"Follower {choice} on {port}. This operation releases torque and writes calibration. "
                "Secure the base and support the arm before proceeding.", parent=parent):
            return
        from pathlib import Path
        override = FOLDER / Path(path).expanduser() if path else None
        for button in buttons:
            button.state(["disabled"])
        active = True
        cancelled.clear()
        advance.clear()
        sample.set("")
        status.set(f"Reading follower {choice} on {port}…")

        def run():
            try:
                robot = make_follower(port, robot_id, override if operation != "read" else None,
                                      disable_torque_on_disconnect=False)
                if operation == "init":
                    pose = initialize(robot)
                    events.put(("done", "Calibration matches. Current starting pose recorded for this check."))
                    events.put(("sample", "\n".join(f"{name:18} {value:+.2f} {'%' if name == KEYS[-1] else '°'}"
                                                     for name, value in pose.items())))
                elif operation == "read":
                    events.put(("readback", (robot_id, read_motor_calibration(robot))))
                    events.put(("done", "Motor calibration read. Review the copy in Settings before saving."))
                elif operation == "restore":
                    restore(robot)
                    events.put(("done", "Saved calibration restored and verified. The arm is released."))
                else:
                    report = record(robot, advance, cancelled, lambda kind, text: events.put((kind, text)))
                    events.put(("done", report))
            except ImportError:
                events.put(("done", "Hardware needs the Python environment with LeRobot and Feetech installed. "
                                     "Set [setup] python in tabletop.ini, then reopen the Studio."))
            except Exception as error:
                events.put(("done", str(error)))

        threading.Thread(target=run, name="so101-hardware", daemon=True).start()

    def poll():
        nonlocal active, phase
        while True:
            try:
                kind, value = events.get_nowait()
            except Empty:
                break
            if kind == "sample":
                sample.set(value)
            elif kind == "readback":
                name, data = value
                readback(name, json.dumps(data, indent=2))
            else:
                status.set(value)
                if kind == "done":
                    phase = None
                    active = False
                    next_button.pack_forget()
                    cancel_button.pack_forget()
                    for button in buttons:
                        button.state(["!disabled"])
                else:
                    phase = kind
                    next_button.configure(text="Capture midpoint" if phase == "midpoint" else "Save range")
                    next_button.state(["!disabled"])
                    cancel_button.state(["!disabled"])
                    next_button.pack(side="left", padx=(0, 8))
                    cancel_button.pack(side="left")
        root.after(80, poll)

    buttons = []
    for title, action in (("Initialize / check", "init"), ("Read motor calibration", "read"),
                          ("Apply saved calibration", "restore"), ("Calibrate new", "record")):
        button = ttk.Button(controls, text=title, command=lambda operation=action: start(operation))
        button.pack(side="left", padx=(0, 6))
        buttons.append(button)
    root.after(80, poll)

    def close():
        if not active:
            root.destroy()
        elif phase:
            cancel()
        else:
            status.set("Wait for the current hardware operation to finish.")

    root.protocol("WM_DELETE_WINDOW", close)
