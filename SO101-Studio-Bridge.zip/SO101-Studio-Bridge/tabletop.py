"""Camera-free XLeRobot tabletop exercise for two standalone SO-101 followers."""
import argparse
import json
import math
import subprocess
import sys
from configparser import ConfigParser
from datetime import datetime
from pathlib import Path
from shutil import copy2

from check_calibration import check
from physical_arm import KEYS, Arm, make_follower, validate_calibration

FOLDER = Path(__file__).resolve().parent
JOINTS = tuple(key.removesuffix(".pos") for key in KEYS)
MODEL_LIMITS = json.loads((FOLDER / "so101-route-settings.js").read_text(encoding="utf-8")
                          .split(" = ", 1)[1].strip().removesuffix(";"))["limits"]
ROUTE_V1 = "so101-tabletop-route-v1"
ROUTE_V2 = "so101-tabletop-route-v2"
HELP = """Commands
  xy X Y         Calculate planar joint angles for X and Y in centimetres
  check [A|B]    Compare saved calibration to the configured motors
  init A         Initialize follower A at its current pose (alias: connect A)
  limits         Show calibrated offsets for the connected follower
  apply A        Teacher: restore A's existing calibration to its motors
  calibrate A    Teacher: record a new LeRobot calibration for A
  read           Read the selected follower's measured joints
  move JOINT N   Preview an offset N from this session's starting pose
  load PATH      Check a downloaded 3D route for the connected follower
  next           Preview the next route step and wait for teacher confirmation
  disconnect     Release the selected follower
  help           Show these commands
  quit           Exit
Use a joint name or a number from 1 to 6 for JOINT."""


def planar_ik(x_cm, y_cm):
    """XLeRobot's two-link model and angle convention, with unreachable targets rejected."""
    x, y = x_cm / 100, y_cm / 100
    upper, lower = 0.1159, 0.1350
    radius = math.hypot(x, y)
    if not abs(upper - lower) < radius < upper + lower:
        raise ValueError("Target is outside the planar reach. Try xy 18 5.")
    elbow = math.acos((radius**2 - upper**2 - lower**2) / (2 * upper * lower))
    shoulder = math.atan2(y, x) + math.atan2(lower * math.sin(elbow), upper + lower * math.cos(elbow))
    shoulder_offset = math.atan2(0.028, 0.11257)
    elbow_offset = shoulder_offset + math.atan2(0.0052, 0.1349)
    return 90 - math.degrees(shoulder + shoulder_offset), math.degrees(elbow + elbow_offset) - 90


def profiles(config, selected=None):
    result = {}
    for label in ("A", "B"):
        port = config.get(label, "port", fallback="").strip()
        robot_id = config.get(label, "id", fallback="").strip()
        if not port and not robot_id and label != selected:
            continue
        if not port or not robot_id:
            if selected is not None and selected != label:
                continue
            raise ValueError(f"Fill in the port and calibration ID for {label} in tabletop.ini.")
        if any(char in robot_id for char in '/\\:') or robot_id in {".", ".."}:
            raise ValueError(f"Use a plain calibration ID for follower {label}.")
        result[label] = port, robot_id
    if not result:
        raise ValueError("Fill in at least one follower in tabletop.ini.")
    if len(result) == 2 and any(a.casefold() == b.casefold() for a, b in zip(*result.values(), strict=True)):
        raise ValueError("Use a different port and calibration ID for each follower.")
    return {selected: result[selected]} if selected else result


def calibration_file(config, label):
    name = config.get(label, "calibration_file", fallback="").strip()
    return FOLDER / Path(name).expanduser() if name else None


def classroom_python(config, folder=FOLDER):
    configured = config.get("setup", "python", fallback="").strip()
    if configured:
        return folder / Path(configured).expanduser()
    parts = ("Scripts", "python.exe") if sys.platform == "win32" else ("bin", "python")
    for environment in (folder / ".robot-venv", folder.parent / ".venv"):
        candidate = environment.joinpath(*parts)
        if candidate.is_file():
            return candidate
    return None


def check_profiles(config, choice=None):
    for label, (port, robot_id) in profiles(config, choice).items():
        print(f"Follower {label} | {port} | {robot_id}", flush=True)
        try:
            robot = make_follower(port, robot_id, calibration_file(config, label),
                                  disable_torque_on_disconnect=False)
            if robot.calibration:
                validate_calibration(robot)
            check(robot)
        except Exception as error:
            print(f"Check failed for {label}: {error}")


def service_calibration(config, label, operation):
    port, robot_id = profiles(config, label)[label]
    override = calibration_file(config, label)
    if override is not None and operation == "calibrate":
        raise ValueError("Clear calibration_file in tabletop.ini before recording a new calibration. "
                         "The imported file will remain untouched.")
    robot = make_follower(port, robot_id, override, disable_torque_on_disconnect=False)
    if operation == "apply":
        validate_calibration(robot)
    print(f"Follower {label} | {port} | {robot_id} | {robot.calibration_fpath}")
    print("Support the arm before continuing: servo torque will be released.")
    prompt = "APPLY" if operation == "apply" else "CALIBRATE"
    if input(f"Teacher: type {prompt} to continue: ").strip() != prompt:
        print("Calibration unchanged.")
        return
    bus = robot.bus
    try:
        bus.connect()
        if operation == "apply":
            bus.disable_torque()
            bus.write_calibration(robot.calibration)
        else:
            path = robot.calibration_fpath
            if path.is_file():
                backup = path.with_suffix(f".{datetime.now():%Y%m%d-%H%M%S-%f}.bak")
                copy2(path, backup)
                print(f"Previous calibration backed up to {backup}")
            robot.calibration = {}
            robot.calibrate()
        validate_calibration(robot)
        if not robot.is_calibrated:
            raise ValueError("Calibration verification failed. Run check before initializing.")
        print("Calibration verified. Support the arm until ready to initialize.")
    finally:
        if bus.is_connected:
            bus.disconnect(disable_torque=False)


def preview_move(arm, joint, offset):
    if joint in map(str, range(1, len(JOINTS) + 1)):
        joint = JOINTS[int(joint) - 1]
    if joint not in JOINTS or not math.isfinite(offset):
        raise ValueError("Use a listed joint and a finite offset.")
    key = f"{joint}.pos"
    target = arm.initial[key] + offset
    low, high = arm.limits(key)
    if not low <= target <= high:
        raise ValueError(f"{joint}: target is outside the calibrated range "
                         f"({low - arm.initial[key]:+.2f} to {high - arm.initial[key]:+.2f} from start).")
    return key, target


def load_route(path, arm, config, label):
    with path.open("rb") as source:
        content = source.read(8193)
    if len(content) > 8192:
        raise ValueError("Route file is too large.")
    return route_targets(json.loads(content.decode("utf-8-sig")), arm, config, label)


def route_targets(route, arm, config, label):
    if isinstance(route, dict) and route.get("schema") == "so101-tabletop-move-set-v1":
        raise ValueError("Open this draft in the 3D Route Lab, run it, then select Download route.")
    if not isinstance(route, dict) or route.get("schema") not in (ROUTE_V1, ROUTE_V2):
        raise ValueError("Choose a route downloaded from the SO-101 3D Route Lab.")
    steps = route.get("steps")
    if not isinstance(steps, list) or not 1 <= len(steps) <= 32:
        raise ValueError("A route needs 1 to 32 steps.")
    targets = []
    for number, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            raise ValueError(f"Step {number}: expected a joint and an angle.")
        joint = step.get("joint")
        gripper = joint == "gripper"
        field = "position_pct" if gripper else "offset_deg"
        value = step.get(field)
        if (not isinstance(joint, str) or joint not in MODEL_LIMITS
                or set(step) != {"joint", field} or type(value) not in (int, float)
                or (gripper and route["schema"] == ROUTE_V1)):
            raise ValueError(f"Step {number}: use a joint and its numeric {field}.")
        low, high = MODEL_LIMITS[joint]
        if route["schema"] == ROUTE_V1:
            low, high = max(-15, low), min(15, high)
        if not low <= value <= high:
            raise ValueError(f"Step {number}: {joint} must stay between {low:g} and {high:g}.")
        sign = config.get(label, joint, fallback="").strip()
        if sign not in {"1", "-1"}:
            raise ValueError(f"Follower {label}: verify {joint}'s direction and set it to 1 or -1 in Settings or tabletop.ini.")
        try:
            if gripper:
                key = "gripper.pos"
                target = value if sign == "1" else 100 - value
                low, high = arm.limits(key)
                if not low <= target <= high:
                    raise ValueError("Gripper target is outside the calibrated range.")
            else:
                key, target = preview_move(arm, joint, int(sign) * value)
        except ValueError as error:
            raise ValueError(f"Step {number}: {error}") from error
        targets.append((key, target, value))
    return targets


def check_route_pose(measured, expected):
    for key in KEYS:
        tolerance = 3 if key == KEYS[-1] else 2
        if not abs(measured[key] - expected[key]) <= tolerance:
            raise ValueError(f"{key}: arm has moved away from the expected route pose. "
                             "Restore the reviewed starting pose and reconnect before loading again.")


def confirm_move(arm, label, key, target, current, expected=None):
    unit = "points" if key == KEYS[-1] else "deg"
    print(f"Follower {label} | {key} | measured {current:+.2f}, target {target:+.2f} {unit}")
    if input("Teacher: type MOVE after checking clearance: ").strip() != "MOVE":
        return False
    if expected is not None:
        check_route_pose(arm.read(), expected)
    arm.move_joint(key, target)
    print(f"Measured after move: {arm.read()[key]:+.2f} {unit}")
    return True


def console(config):
    print("XLeRobot tabletop lab. No arm connected.")
    print("Joints:", ", ".join(f"{i} {name}" for i, name in enumerate(JOINTS, 1)))
    print(HELP)
    arm = None
    label = None
    route = []
    cursor = 0
    expected = {}
    try:
        while True:
            try:
                command = input(f"{label or 'preview'}> ").strip()
                operation, _, argument = command.partition(" ")
                line = command.lower().split()
                match line:
                    case ["quit"]:
                        return
                    case []:
                        continue
                    case ["help"]:
                        print(HELP)
                    case ["xy", x, y]:
                        shoulder, elbow = planar_ik(float(x), float(y))
                        print(f"Planar preview | shoulder lift {shoulder:+.2f} deg | elbow flex {elbow:+.2f} deg")
                    case ["check"] if arm is None:
                        check_profiles(config)
                    case ["check", choice] if arm is None and choice in {"a", "b"}:
                        check_profiles(config, choice.upper())
                    case ["apply" | "calibrate" as action, choice] if arm is None and choice in {"a", "b"}:
                        service_calibration(config, choice.upper(), action)
                    case ["connect" | "init", choice] if arm is None and choice in {"a", "b"}:
                        target_label = choice.upper()
                        port, robot_id = profiles(config, target_label)[target_label]
                        path = calibration_file(config, target_label)
                        print(f"Follower {target_label}: {port} | {robot_id}. Support the arm and clear the sweep.")
                        if input("Teacher: type CONNECT to continue: ").strip() == "CONNECT":
                            arm = Arm(port, robot_id, path) if path is not None else Arm(port, robot_id)
                            label = target_label
                            print(f"Follower {label} connected. Offsets are relative to this starting pose.")
                    case ["limits"] if arm is not None:
                        for key in KEYS:
                            low, high = arm.limits(key)
                            unit = "points" if key == KEYS[-1] else "deg"
                            start = arm.initial[key]
                            print(f"{key}: {low - start:+.2f} to {high - start:+.2f} {unit} from start")
                    case ["disconnect"] if arm is not None:
                        arm.close()
                        arm, label = None, None
                        route = []
                        print("Follower disconnected.")
                    case ["read"] if arm is not None:
                        reading = arm.read()
                        for name, key in zip(JOINTS, KEYS, strict=True):
                            unit = "points" if name == "gripper" else "deg"
                            print(f"{name} {reading[key]:+.2f} {unit} ({reading[key] - arm.initial[key]:+.2f} from start)")
                    case _ if operation.lower() == "load" and argument.strip() and arm is not None:
                        route = []
                        name = argument.strip()
                        if len(name) >= 2 and name[0] in {"'", '"'} and name[0] == name[-1]:
                            name = name[1:-1]
                        path = Path(name).expanduser()
                        targets = load_route(path, arm, config, label)
                        expected = arm.initial.copy()
                        check_route_pose(arm.read(), expected)
                        route, cursor = targets, 0
                        print(f"Checked {len(route)} steps for follower {label}. Type next when ready.")
                    case ["next"] if arm is not None and cursor < len(route):
                        measured = arm.read()
                        key, target, offset = route[cursor]
                        try:
                            check_route_pose(measured, expected)
                            kind = f"gripper travel {offset:g}%" if key == KEYS[-1] else f"model offset {offset:+g} deg"
                            print(f"Step {cursor + 1}/{len(route)} | {kind}")
                            moved = confirm_move(arm, label, key, target, measured[key], expected)
                        except ValueError:
                            route = []
                            raise
                        if moved:
                            expected[key] = target
                            cursor += 1
                            print("Route complete." if cursor == len(route) else "Type next for the following step.")
                        else:
                            print("Step held. Type next to preview it again.")
                    case ["next"] if arm is not None:
                        print("Load a route with pending steps first.")
                    case ["move", joint, offset] if arm is not None:
                        key, target = preview_move(arm, joint, float(offset))
                        if confirm_move(arm, label, key, target, arm.read()[key]):
                            if cursor < len(route):
                                print("Manual move cleared the pending route.")
                            route = []
                    case _:
                        print("Use help for commands. Disconnect the active arm before checking or switching.")
            except (ValueError, ImportError, OSError) as error:
                print(error)
    except (EOFError, KeyboardInterrupt):
        print("\nSession ended.")
    finally:
        if arm is not None:
            arm.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--configured", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    config = ConfigParser(interpolation=None)
    config.read(FOLDER / "tabletop.ini", encoding="utf-8-sig")
    python = classroom_python(config)
    if python and not args.configured:
        return subprocess.run([str(python), "-B", __file__, "--configured"], check=False).returncode
    console(config)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        sys.exit(f"Tabletop session stopped: {error}")
