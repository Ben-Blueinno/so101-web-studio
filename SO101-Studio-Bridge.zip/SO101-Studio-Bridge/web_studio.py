"""Serve the SO-101 Studio on loopback and own its serial connection."""
import argparse
import json
from math import isfinite
import mimetypes
import secrets
import subprocess
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from physical_arm import Arm, KEYS, make_follower
from lerobot_export import export_lerobot
from program_editor import LEROBOT_EXAMPLE, compile_program
from setup_profiles import FIELDS, SetupStore, atomic_write, available_ports
from studio_hardware import read_motor_calibration, record, restore
from tabletop import FOLDER, MODEL_LIMITS, ROUTE_V2, calibration_file, check_route_pose, classroom_python, profiles, route_targets

ASSETS = {"studio.html", "studio.js", "so101-route-lab.js", "so101-route-settings.js",
          "so101-tabletop-model.js", "Python Codebook.html", "SO-101 3D Route Lab.html"}
HOSTED_ORIGIN = "https://ben-blueinno.github.io"
HOSTED_URL = HOSTED_ORIGIN + "/so101-web-studio/"
HOSTED_ACTIONS = {"session", "telemetry", "init", "disconnect", "read-pose", "compile",
                  "deploy", "move", "stop", "discard", "prepare-rest", "return-rest"}


def model_route(program, config, label):
    if program.get("coordinates") != "lerobot":
        return program
    steps = []
    for index, step in enumerate(program["steps"], 1):
        joint = step["joint"]
        reversed_axis = config.get(label, joint, fallback="") == "-1"
        if joint == "gripper":
            percent = step["position_pct"]
            mapped = {"joint": joint, "position_pct": 100 - percent if reversed_axis else percent}
        else:
            offset = step["offset_deg"] * (-1 if reversed_axis else 1)
            low, high = MODEL_LIMITS[joint]
            if not low <= offset <= high:
                raise ValueError(f"Step {index}: {joint} exceeds the model range for follower {label}.")
            mapped = {"joint": joint, "offset_deg": offset}
        steps.append(mapped)
    return {"schema": program["schema"], "steps": steps}


def model_pose(observation, config, label):
    """Map calibrated encoder readings to renderer offsets from the reference pose."""
    pose = {}
    for joint, (low, high) in MODEL_LIMITS.items():
        value = observation[f"{joint}.pos"]
        reversed_axis = config.get(label, joint, fallback="") == "-1"
        if joint == "gripper":
            pose[joint] = 100 - value if reversed_axis else value
        else:
            # LeRobot reports degrees from the calibrated range midpoint.
            pose[joint] = (low + high) / 2 + (-value if reversed_axis else value)
    return pose


class Studio:
    def __init__(self, folder=FOLDER):
        self.store = SetupStore(folder)
        self.lock = threading.Lock()
        self.cal_lock = threading.Lock()
        self.arm = None
        self.label = None
        self.config = None
        self.program = None
        self.model_program = None
        self.source = None
        self.preview_id = None
        self.plan_id = None
        self.targets = []
        self.cursor = 0
        self.expected = {}
        self.measured = None
        self.feedback = None
        self.rest = None
        self.rest_binding = None
        self.rest_offer = None
        self.stop_motion = threading.Event()
        self.calibration = {"phase": "idle", "message": "", "sample": ""}
        self.advance = threading.Event()
        self.cancel = threading.Event()
        self.cal_thread = None

    def cal_status(self, phase=None, message=None, sample=None):
        with self.cal_lock:
            for key, val in (("phase", phase), ("message", message), ("sample", sample)):
                if val is not None:
                    self.calibration[key] = val
            return self.calibration.copy()

    def invalidate(self):
        self.targets = []
        self.cursor = 0
        self.plan_id = None

    def settings(self):
        cfg = self.store.read()
        return {"profiles": {label: {f: cfg.get(label, f, fallback="") for f in FIELDS}
                             for label in ("A", "B")}, "ports": available_ports(),
                "files": sorted(p.name for p in self.store.folder.glob("*.json") if not p.is_symlink())}

    def require_idle(self):
        if self.arm is not None:
            raise ValueError("Disconnect the initialized arm before updating settings or calibration.")

    def profile(self, data):
        label = data.get("label")
        if label not in ("A", "B"):
            raise ValueError("Choose follower A or B.")
        config = self.store.read()
        port, identity = profiles(config, label)[label]
        return config, label, port, identity, calibration_file(config, label)

    def arm_snapshot(self):
        if self.arm is None:
            return None
        return {"label": self.label, "pose": self.measured,
                "model_pose": model_pose(self.measured, self.config, self.label),
                "preview_start": model_pose(self.arm.initial, self.config, self.label),
                "at_rest": all(abs(self.measured[key] - self.rest[key]) <= 0.5 for key in KEYS)}

    def publish_pose(self, pose, joint=None):
        self.measured = pose
        self.feedback = {"arm": self.arm_snapshot(), "joint": joint, "live": True}

    def sample_motion(self, key, pose):
        self.publish_pose(pose, key.removesuffix(".pos"))
        self.check_stop(None)

    def rest_file(self):
        return self.store.root / f"rest-pose-{self.label}.json"

    def load_rest(self):
        try:
            record = json.loads(self.rest_file().read_text(encoding="utf-8"))
            if record["binding"] == self.rest_binding:
                pose = record["pose"]
                if set(pose) == set(KEYS) and all(self.valid_rest(key, pose[key]) for key in KEYS):
                    return pose
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return self.arm.initial.copy()

    def valid_rest(self, key, value):
        low, high = self.arm.limits(key)
        return type(value) in (int, float) and isfinite(value) and low <= value <= high

    def return_to_rest(self, data):
        offer, self.rest_offer = self.rest_offer, None
        if offer is None or data.get("token") != offer[0]:
            raise ValueError("Review the return-to-rest warning again.")
        _, start, axes = offer
        current = self.arm.read()
        self.publish_pose(current)
        if any(abs(current[key] - start[key]) > 0.5 for key in KEYS):
            raise ValueError("The arm position changed. Review the return path again.")
        self.preview_id = None
        self.stop_motion.clear()
        self.arm.enable()
        expected = start.copy()
        for key in axes:
            self.check_stop(None)
            self.publish_pose(self.arm.read(), key.removesuffix(".pos"))
            check_route_pose(self.measured, expected)
            self.arm.move_joint(key, self.rest[key], on_pose=lambda pose: self.sample_motion(key, pose))
            self.publish_pose(self.arm.read())
            expected[key] = self.rest[key]
        self.arm.initial = self.measured.copy()
        self.publish_pose(self.measured)
        if not self.feedback["arm"]["at_rest"]:
            raise ValueError("The final encoder readings are outside the rest tolerance.")
        return self.arm_snapshot()

    def command(self, action, data):
        if action == "cal-status":
            return self.cal_status()
        if action == "cal-next":
            with self.cal_lock:
                if self.calibration["phase"] not in ("midpoint", "range"):
                    raise ValueError("Wait for the requested calibration phase.")
                self.calibration.update(phase="working", message="Capturing calibration…")
                self.advance.set()
                return self.calibration.copy()
        if action == "cal-cancel":
            self.cancel.set()
            return self.cal_status()
        if action == "stop":
            self.stop_motion.set()
            return {}
        if not self.lock.acquire(timeout=0 if action == "telemetry" else 0.15):
            if action == "telemetry":
                return self.feedback or {"arm": None, "joint": None, "live": False}
            raise ValueError("An arm operation is in progress.")
        try:
            if self.cal_thread is not None and self.cal_thread.is_alive() and action not in ("session", "settings", "telemetry"):
                raise ValueError("Finish or cancel the calibration in progress.")
            return self.dispatch(action, data)
        finally:
            self.lock.release()

    def dispatch(self, action, data):
        if action == "telemetry":
            if self.arm is None:
                return {"arm": None, "joint": None, "live": False}
            self.publish_pose(self.arm.read())
            return self.feedback
        if action == "session":
            return {"arm": self.arm_snapshot(),
                    "step": None if self.plan_id is None else self.next_step(), "source": self.source}
        if action in ("compile", "export-lerobot"):
            label, source = data.get("label", "A"), data.get("source")
            if label not in ("A", "B") or not isinstance(source, str):
                raise ValueError("Choose a follower and enter a Python program.")
            config = self.store.read()
            if action == "export-lerobot":
                directions = {joint: int(value) for joint in MODEL_LIMITS
                              if (value := config.get(label, joint, fallback="")) in ("1", "-1")}
                return {"code": export_lerobot(source, directions)}
            if self.plan_id is not None:
                raise ValueError("Finish or discard the current deployment first.")
            program = compile_program(source)
            rendered = model_route(program, config, label)
            self.program, self.model_program = program, rendered
            self.source = source
            self.preview_id = secrets.token_urlsafe(16)
            self.invalidate()
            return {"route": rendered, "preview_id": self.preview_id}
        if action == "settings":
            return self.settings()
        if action == "cal-view":
            path = self.store.folder / data.get("name", "")
            self.store.require_managed(path)
            return {"text": self.store.read_calibration(path)}
        if action in ("profile-save", "profile-remove", "cal-save", "cal-archive"):
            self.require_idle()
            if action == "profile-save":
                values = data.get("values", {})
                if not isinstance(values, dict) or any(not isinstance(v, str) or "\n" in v or "\r" in v
                                                       for v in values.values()):
                    raise ValueError("Enter valid profile fields.")
                self.store.save_profile(data.get("label"), values)
            elif action == "profile-remove":
                self.store.save_profile(data.get("label"), None)
            elif action == "cal-save":
                self.store.save_calibration(data.get("name", ""), data.get("text", ""), data.get("replace") is True)
            else:
                self.store.archive_calibration(self.store.folder / data.get("name", ""))
            return self.settings()
        if action == "disconnect":
            if self.arm is not None:
                self.arm.close()
                self.arm = None
                self.measured = None
                self.feedback = None
                self.rest_offer = None
            self.preview_id = None
            self.invalidate()
            return {}
        if action == "read-pose":
            if self.arm is None:
                raise ValueError("Initialize the follower in Arm setup first.")
            if self.plan_id is not None:
                raise ValueError("Finish or discard the current deployment before setting a new starting pose.")
            self.publish_pose(self.arm.read())
            self.arm.initial = self.measured.copy()
            self.publish_pose(self.measured)
            self.rest_offer = None
            self.preview_id = None
            return self.arm_snapshot()
        if action in ("save-rest", "prepare-rest", "return-rest"):
            if self.arm is None:
                raise ValueError("Initialize the follower in Arm setup first.")
            if self.plan_id is not None:
                raise ValueError("Finish or discard the current deployment first.")
            if action == "return-rest":
                try:
                    return self.return_to_rest(data)
                finally:
                    self.publish_pose(self.measured)
            self.publish_pose(self.arm.read())
            if action == "save-rest":
                if not all(self.valid_rest(key, self.measured[key]) for key in KEYS):
                    raise ValueError("The current pose must be inside the calibrated limits.")
                atomic_write(self.rest_file(), json.dumps({"binding": self.rest_binding, "pose": self.measured}))
                self.rest = self.measured.copy()
                self.publish_pose(self.measured)
                self.rest_offer = None
                return self.arm_snapshot()
            axes = [key for key in reversed(KEYS) if abs(self.measured[key] - self.rest[key]) > 0.5]
            if not all(self.valid_rest(key, self.rest[key]) for key in axes):
                raise ValueError("A rest target is outside the calibrated limits. Save a new rest pose.")
            token = secrets.token_urlsafe(16) if axes else None
            self.rest_offer = (token, self.measured.copy(), axes) if axes else None
            return {"token": token, "joints": [key.removesuffix(".pos") for key in axes],
                    "arm": self.arm_snapshot()}
        if action in ("init", "cal-read", "cal-apply", "cal-start"):
            self.require_idle()
            config, label, port, identity, path = self.profile(data)
            if action == "init":
                self.arm = Arm(port, identity, path, enable=False,
                               shoulder_lift_p_gain=config.getint(label, "shoulder_lift_p_gain", fallback=None),
                               shoulder_pan_p_gain=config.getint(label, "shoulder_pan_p_gain", fallback=None))
                self.label, self.config = label, config
                self.rest_binding = [identity, port, self.arm.calibration_signature()]
                self.rest = self.load_rest()
                self.publish_pose(self.arm.initial.copy())
                self.preview_id = None
                self.invalidate()
                return self.arm_snapshot()
            robot = make_follower(port, identity, path if action != "cal-read" else None,
                                  disable_torque_on_disconnect=False)
            if action == "cal-read":
                return {"text": json.dumps(read_motor_calibration(robot), indent=2),
                        "name": f"{identity}-readback"[:60]}
            if data.get("confirmed") is not True:
                raise ValueError("Confirm the arm is supported before changing calibration.")
            if action == "cal-apply":
                restore(robot)
                return {"message": "Calibration restored and verified. The arm is released."}
            if path is not None:
                raise ValueError("Save the profile using the LeRobot default calibration path before recording.")
            self.cancel.clear()
            self.advance.clear()
            self.cal_status("working", "Connecting and releasing torque…", "")
            self.cal_thread = threading.Thread(target=self.record_calibration, args=(robot,), daemon=True)
            self.cal_thread.start()
            return self.cal_status()
        if action == "discard":
            self.invalidate()
            return {}
        if action not in ("deploy", "move"):
            raise ValueError("Unknown Studio operation.")
        if self.arm is None:
            raise ValueError("Initialize the follower in Arm setup first.")
        if action == "deploy":
            if self.preview_id is None or data.get("preview_id") != self.preview_id:
                raise ValueError("Preview the current Python program again.")
            if self.plan_id is not None:
                raise ValueError("Finish or discard the current deployment first.")
            check_route_pose(self.arm.read(), self.arm.initial)
            mapped = model_route(self.program, self.config, self.label)
            if mapped != self.model_program:
                raise ValueError("Preview again using the initialized follower's joint directions.")
            route = dict(mapped, schema=ROUTE_V2)
            self.targets = route_targets(route, self.arm, self.config, self.label)
            self.expected = self.arm.initial.copy()
            self.plan_id = secrets.token_urlsafe(16)
            self.cursor = 0
            return self.next_step()
        if data.get("plan_id") != self.plan_id or not self.plan_id or data.get("index") != self.cursor:
            raise ValueError("The selected step is no longer current.")
        key, target, _ = self.targets[self.cursor]
        self.stop_motion.clear()
        try:
            before = self.arm.read()
            check_route_pose(before, self.expected)
            self.check_stop(None)
            self.arm.enable()
            check_route_pose(self.arm.read(), self.expected)
            self.publish_pose(before, key.removesuffix(".pos"))
            self.arm.move_joint(key, target, on_pose=lambda pose: self.sample_motion(key, pose))
            self.publish_pose(self.arm.read())
        except Exception:
            if self.measured is not None:
                self.publish_pose(self.measured)
            self.invalidate()
            raise
        self.expected[key] = target
        self.cursor += 1
        return {**self.next_step(), "arm": self.arm_snapshot(),
                "result": {"index": data["index"], "joint": key.removesuffix(".pos"),
                           "before": before[key], "target": target, "measured": self.measured[key]}}

    def check_stop(self, _reading):
        if self.stop_motion.is_set():
            raise InterruptedError("Motion stopped. Review the arm pose before preparing another route.")

    def next_step(self):
        if self.cursor == len(self.targets):
            self.invalidate()
            return {"done": True}
        key, target, _ = self.targets[self.cursor]
        return {"plan_id": self.plan_id, "index": self.cursor, "count": len(self.targets),
                "joint": key.removesuffix(".pos"), "target": target}

    def record_calibration(self, robot):
        def notify(kind, value):
            if kind == "sample":
                self.cal_status(sample=value)
            else:
                self.cal_status(kind, value, "")
        try:
            outcome = record(robot, self.advance, self.cancel, notify)
        except Exception as error:
            self.cal_status("error", str(error))
        else:
            self.cal_status("done", outcome)

    def close(self):
        self.cancel.set()
        self.stop_motion.set()
        if self.cal_thread is not None:
            self.cal_thread.join()
        with self.lock:
            if self.arm is not None:
                self.arm.close()


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *_args):
        pass

    def respond(self, status, content, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        if self.hosted_request():
            self.send_header("Access-Control-Allow-Origin", HOSTED_ORIGIN)
            self.send_header("Vary", "Origin")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.end_headers()
        try:
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_json(self, status, data):
        self.respond(status, json.dumps(data).encode())

    def hosted_request(self):
        return bool(self.server.hosted_code and self.headers.get("Host") == self.server.host
                    and self.headers.get("Origin") == HOSTED_ORIGIN
                    and self.path.removeprefix("/api/") in HOSTED_ACTIONS
                    and self.path.startswith("/api/"))

    def do_OPTIONS(self):
        if not self.hosted_request() or self.headers.get("Access-Control-Request-Method") != "POST":
            return self.send_json(403, {"error": "Hosted access is unavailable for this request."})
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", HOSTED_ORIGIN)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "POST")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Studio-Token")
        if self.headers.get("Access-Control-Request-Private-Network") == "true":
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def do_GET(self):
        if self.headers.get("Host") != self.server.host:
            return self.send_json(403, {"error": "Open the Studio from its local address."})
        path = unquote(urlsplit(self.path).path)
        if path == "/api/bootstrap":
            return self.send_json(200, {"token": self.server.token, "example": LEROBOT_EXAMPLE})
        name = "studio.html" if path == "/" else path.removeprefix("/")
        if name not in ASSETS:
            return self.send_json(404, {"error": "File not found."})
        path = self.server.app.store.root / name
        mime = mimetypes.guess_type(name)[0] or "application/octet-stream"
        self.respond(200, path.read_bytes(), mime + "; charset=utf-8")

    def do_POST(self):
        origin = self.headers.get("Origin")
        code = self.headers.get("X-Studio-Token", "").encode()
        local = (self.headers.get("Host") == self.server.host and origin == self.server.origin
                 and secrets.compare_digest(code, self.server.token.encode()))
        hosted = self.hosted_request() and secrets.compare_digest(code, self.server.hosted_code.encode())
        if not (local or hosted):
            return self.send_json(403, {"error": "Studio connection not authorized. Check the bridge code."})
        if not self.path.startswith("/api/") or self.headers.get_content_type() != "application/json":
            return self.send_json(400, {"error": "Invalid Studio request."})
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= 40000:
                raise ValueError("Studio request is too large or empty.")
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ValueError("Expected a Studio JSON object.")
            result = self.server.app.command(self.path.removeprefix("/api/"), data)
        except ImportError:
            return self.send_json(400, {"error": "Hardware needs the Python environment with LeRobot and Feetech. "
                                                "Set the Python path in the launcher's tabletop.ini."})
        except Exception as error:
            return self.send_json(400, {"error": str(error)})
        return self.send_json(200, result)


def create_server(port, app=None, *, hosted=False):
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.host = f"127.0.0.1:{server.server_port}"
    server.origin = f"http://{server.host}"
    server.token = secrets.token_urlsafe(32)
    server.hosted_code = secrets.token_urlsafe(24) if hosted else None
    server.app = app or Studio()
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--hosted", action="store_true", help="Pair the published Studio with this computer")
    parser.add_argument("--configured", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    python = classroom_python(SetupStore(FOLDER).read())
    if python and not args.configured:
        return subprocess.call([str(python), "-B", __file__, *sys.argv[1:], "--configured"])
    try:
        server = create_server(args.port, hosted=args.hosted)
    except OSError as error:
        sys.exit(f"Could not start the Studio on port {args.port}: {error}. Open the existing Studio or free this port.")
    with server:
        print(f"SO-101 Web Studio · {server.origin}\nKeep this window open. Press Ctrl+C to stop.", flush=True)
        if args.hosted:
            print(f"GitHub Studio pairing code: {server.hosted_code}\nHosted Studio: {HOSTED_URL}", flush=True)
        if not args.no_browser:
            webbrowser.open(HOSTED_URL if args.hosted else server.origin)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.app.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
